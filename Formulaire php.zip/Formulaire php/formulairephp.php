<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="stylephp.css">    
    <title>Formulaire</title>
</head>
<body>

<center> <form action="affiche.php" method="POST">  
                   <table border="0px">
                        <tr>
                            <td colspan="2"> <h2>Formulaire</h2></td>
                        </tr>
                        <tr>
                            <td class="label"> Nom </td>
                            <td><input type="text" placeholder="Nom" name="nom" class="input1"></td>
                        </tr>
                        <tr>
                            <td class="label"> Prenom </td>
                            <td> <input  type="text" placeholder="Prenom" name="prenom" class="input1"> </td>
                        </tr>
                        <tr>
                            <td class="label">Age </td>
                            <td> <input type="text" placeholder="Age" name="age" class="input1"></td>
                        </tr>
                        <tr>
                            <td class="label"> Telephone </td>
                            <td> <input type="text" placeholder="Telephone" name="tel" class="input1"></td>
                        </tr>
                        <tr>
                            <td class="label"> Adresse </td>
                            <td><input type="text" placeholder="Adresse" name="adresse" class="input1"></td>
                        </tr>
                        <tr>
                            <td class="label"> Message </td>
                            <td><textarea type="text" placeholder="Message" name="msg"></textarea></td>
                        </tr>
                        <tr>
                            <td colspan="2">
                                <button type="submit" name="envoyer" class="btnsend">Envoyer</button>
                            </td>
                        </tr>
                    </table>

                </form>
        </center> 
</body>
</html>