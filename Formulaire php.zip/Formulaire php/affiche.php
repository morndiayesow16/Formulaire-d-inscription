
    <!--Recuperation des données -->
    <?php 
     $nom = $_POST['nom'];
     $prenom = $_POST['prenom'];
     $age = $_POST['age'];
     $tel = $_POST['tel'];
     $adresse = $_POST['adresse'];
     $msg = $_POST['msg'];
     ?>
        <!--Affichage des données-->
            <center> <table border="0px">
                        <tr>
                            <td colspan="2"> <h2>Affichage</h2></td>
                        </tr>
                        <tr>
                            <td class="label"> Nom :</td>
                            <td class="input2"> <?php echo $nom; ?> </td>
                        </tr>
                        <tr>
                            <td class="label"> Prenom :</td>
                            <td class="input2"><?php echo $prenom; ?></td>
                        </tr>
                        <tr>
                            <td class="label">Age :</td>
                            <td class="input2"><?php echo $age; ?></td>
                        </tr>
                        <tr>
                            <td class="label"> Telephone :</td>
                            <td class="input2"> <?php echo $tel; ?> </td>
                        </tr>
                        <tr>
                            <td class="label"> Adresse :</td>
                            <td class="input2"> <?php echo $adresse; ?></td>
                        </tr>
                        <tr>
                            <td class="label"> Message :</td>
                            <td class="input2"> <?php echo $msg; ?></td>
                        </tr>
                    </table>
            </center> 